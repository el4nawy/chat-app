import React from 'react'

function chatApp() {
  return (
    <div>chatApp</div>
  )
}

export default chatApp